import Link from 'next/link';
import { useState } from 'react';

/**
 * Simple responsive header for the GlamorousDesi storefront. Displays the
 * brand name, a navigation menu, and cart/account links. In a production
 * environment you might pull navigation data from Shopify, but here we
 * hard‑code a few sample links.
 */
export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header>
      <div className="container" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            aria-label="Toggle navigation"
            style={{ display: 'inline-block', background: 'none', border: 'none', cursor: 'pointer' }}
          >
            <span style={{ fontSize: '1.5rem' }}>☰</span>
          </button>
          <Link href="/">
            <a style={{ fontWeight: 'bold', fontSize: '1.25rem', color: '#d23468' }}>GlamorousDesi</a>
          </Link>
        </div>
        <nav style={{ display: isMenuOpen ? 'block' : 'none' }}>
          <ul style={{ listStyle: 'none', padding: 0, margin: 0, display: 'flex', gap: '1.5rem', flexDirection: isMenuOpen ? 'column' : 'row' }}>
            <li>
              <Link href="/collections/all">
                <a>Shop</a>
              </Link>
            </li>
            <li>
              <Link href="/blog">
                <a>Blog</a>
              </Link>
            </li>
            <li>
              <Link href="/about">
                <a>About</a>
              </Link>
            </li>
            <li>
              <Link href="https://www.myshaadidreams.com" target="_blank" rel="noopener noreferrer">
                <a>MyShaadiDreams</a>
              </Link>
            </li>
          </ul>
        </nav>
        <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
          <Link href="/account">
            <a aria-label="Account">👤</a>
          </Link>
          <Link href="/cart">
            <a aria-label="Cart">🛒</a>
          </Link>
        </div>
      </div>
    </header>
  );
}