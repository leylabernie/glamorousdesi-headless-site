import Link from 'next/link';

/**
 * Hero section for the home page. Highlights the brand and encourages
 * visitors to begin shopping. You can replace the placeholder background
 * image by placing an image named `hero-bg-placeholder.jpg` in the public
 * folder or adjusting the CSS in `styles/globals.css`.
 */
export default function HeroSection() {
  return (
    <section className="hero">
      <div className="container" style={{ maxWidth: '800px' }}>
        <h1>Discover Indian Ethnic Wear That Inspires</h1>
        <p>
          Embrace tradition with a modern twist. Explore our curated collection
          of lehengas, sarees and more — perfect for weddings and celebrations.
        </p>
        <Link href="/collections/all">
          <a className="btn">Shop now</a>
        </Link>
      </div>
    </section>
  );
}