import { useEffect, useState } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { getProducts } from '@/lib/shopify';

/**
 * Displays a grid of products fetched from Shopify. When running locally
 * without a valid Storefront API token, the `getProducts` function will
 * return a static set of example products. Each product card links to
 * its product page (not implemented in this skeleton).
 */
export default function ProductGrid() {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    async function loadProducts() {
      const items = await getProducts({ first: 8 });
      setProducts(items);
    }
    loadProducts();
  }, []);

  return (
    <div className="product-grid">
      {products.map((product) => (
        <div key={product.id} className="product-card">
          {product.image && (
            <Image
              src={product.image}
              width={400}
              height={400}
              alt={product.title}
            />
          )}
          <div className="info">
            <h3>{product.title}</h3>
            <p>{product.price}</p>
            <Link href={`/products/${product.handle}`}>
              <a className="btn" style={{ marginTop: '0.5rem' }}>View</a>
            </Link>
          </div>
        </div>
      ))}
    </div>
  );
}