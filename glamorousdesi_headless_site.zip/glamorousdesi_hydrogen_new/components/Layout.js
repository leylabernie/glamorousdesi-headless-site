import Header from './Header';
import Footer from './Footer';

/**
 * Layout component used to wrap all pages. Contains the global header and footer
 * and renders children in between. This ensures a consistent look and feel
 * across the site.
 */
export default function Layout({ children }) {
  return (
    <>
      <Header />
      <main className="container">{children}</main>
      <Footer />
    </>
  );
}