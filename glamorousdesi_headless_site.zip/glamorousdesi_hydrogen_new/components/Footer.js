/**
 * Global footer component. Includes copyright notice and a back to top link.
 */
export default function Footer() {
  return (
    <footer>
      <p>&copy; {new Date().getFullYear()} GlamorousDesi. All rights reserved.</p>
      <p>
        <a href="#" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>Back to top ↑</a>
      </p>
    </footer>
  );
}